#!/usr/bin/env bash
set -euo pipefail

capsule_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$capsule_root"

./scripts/verify-source.sh
manifest_before="$(shasum -a 256 lake-manifest.json | awk '{print $1}')"
lake update
lake exe cache get
manifest_after="$(shasum -a 256 lake-manifest.json | awk '{print $1}')"
test "$manifest_before" = "$manifest_after"
echo "lake-manifest.json unchanged: $manifest_after"

lean_version="$(lake env lean --version)"
case "$lean_version" in
  *"Lean (version 4.33.0-rc2"*"commit d8b18978322de05a8f3dba51ef03cf5461676c17"*) ;;
  *) echo "unexpected Lean binary: $lean_version" >&2; exit 1 ;;
esac
echo "Lean binary: $lean_version"

mathlib_head="$(git -C .lake/packages/mathlib rev-parse HEAD)"
test "$mathlib_head" = "641fbd329d4ffb62bef83c51f54088469056bd36"
test -z "$(git -C .lake/packages/mathlib status --porcelain --untracked-files=no)"
echo "mathlib checkout: $mathlib_head (clean)"

lake build

audit_log="$(mktemp)"
trap 'rm -f "$audit_log"' EXIT
lake env lean LogdetLean/PaperAxiomAudit.lean 2>&1 | tee "$audit_log"

python3 - "$audit_log" <<'PY'
import re
import sys
from pathlib import Path

text = Path(sys.argv[1]).read_text(encoding="utf-8")
reports = re.findall(
    r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", text, re.S
)
expected_names = {
    "LogdetLean.map_centeredSampleCorrelationDet_succ_eq_map_product_betaFactors",
    "LogdetLean.uniformNullEdgeworthTarget_proved",
    "LogdetLean.tendsto_uniformActualNullSharpKolmogorov_relative_error_zero",
    "LogdetLean.paperTheoremFiveOne_exact",
    "LogdetLean.paperTheoremFiveTwo_exact",
    "LogdetLean.paperTheoremFiveTwo_arbitraryCovariance_exact",
    "LogdetLean.tendsto_nullASeries_div_uniformScale",
    "LogdetLean.tendsto_nullVSeries_div_uniformScale",
    "LogdetLean.tendsto_square_nullVSeries_sub_two_log",
    "LogdetLean.tendsto_scaledNullKolmogorovSup_closed",
    "LogdetLean.nullSharpSupremumConstant_decimal8",
}
names = [name for name, _ in reports]
if len(names) != len(set(names)):
    raise SystemExit("duplicate endpoint axiom report")
if set(names) != expected_names:
    raise SystemExit(
        f"endpoint axiom reports differ: missing={sorted(expected_names-set(names))}, "
        f"extra={sorted(set(names)-expected_names)}"
    )
allowed = {"propext", "Classical.choice", "Quot.sound"}
for endpoint, report in reports:
    axiom_names = {item.strip() for item in report.split(",") if item.strip()}
    if axiom_names != allowed:
        raise SystemExit(
            f"unexpected axiom set for {endpoint}: {sorted(axiom_names)}"
        )
if text.count("Declarations are sorry-free!") != 1:
    raise SystemExit("environment-aware #print sorries did not report exactly one clean result")
print("All 11 advertised endpoints use exactly the reproduced allowed axiom set.")
print("The environment-aware endpoint import closure is sorry-free.")
PY

for module in \
  LogdetLean.SampleCorrelationBeta \
  LogdetLean.NullUniformEdgeworthTarget \
  LogdetLean.GeneralRPaperExactTranslation \
  LogdetLean.NullAUniformAsymptotics \
  LogdetLean.NullVUniformAsymptotics \
  LogdetLean.NullRefinedAsymptotics \
  LogdetLean.NullSharpSupremum \
  LogdetLean.NullSharpSupremumDecimal
do
  lake env leanchecker "$module"
done

echo "Paper-specific Lean verification passed."
