import LogdetLean.VonNeumannTypicality.Entropy.EndpointBound
import Mathlib.Analysis.Calculus.MeanValue

/-!
# Lipschitz regularization of the entropy profile

The logarithmic derivative estimate becomes a uniform Lipschitz estimate once
the singular-value coordinate is clipped at `1-η`.  This module proves that
finite scalar step directly from the mean value theorem.
-/

open Real Set

namespace LogdetLean.VonNeumannTypicality

noncomputable section

/-- Explicit Lipschitz constant for the profile clipped at distance `η` from
the pure-mode endpoint. -/
def regularizedEntropyLipschitzConstant (s η : ℝ) : ℝ :=
  endpointDerivativeConstant s * Real.log (Real.exp 1 / η)

theorem regularizedEntropyLipschitzConstant_nonneg {s η : ℝ}
    (hη0 : 0 < η) (hη1 : η ≤ 1) :
    0 ≤ regularizedEntropyLipschitzConstant s η := by
  have hquot : 1 ≤ Real.exp 1 / η := by
    apply (le_div_iff₀ hη0).2
    have he : 1 ≤ Real.exp 1 := by
      simpa using Real.exp_monotone (show (0 : ℝ) ≤ 1 by norm_num)
    simpa using hη1.trans he
  unfold regularizedEntropyLipschitzConstant
  exact mul_nonneg (endpointDerivativeConstant_nonneg s)
    (Real.log_nonneg hquot)

/-- On the closed interval ending at `1-η`, the unregularized entropy profile
has the expected logarithmic Lipschitz constant. -/
theorem abs_entropyProfile_sub_le_cutoff {s η x y : ℝ}
    (hs : s ≠ 0) (hη0 : 0 < η) (hη1 : η ≤ 1)
    (hx : x ∈ Icc (0 : ℝ) (1 - η))
    (hy : y ∈ Icc (0 : ℝ) (1 - η)) :
    |entropyProfile s x - entropyProfile s y| ≤
      regularizedEntropyLipschitzConstant s η * |x - y| := by
  have hdiff : ∀ z ∈ Icc (0 : ℝ) (1 - η),
      DifferentiableAt ℝ (entropyProfile s) z := by
    intro z hz
    exact (hasDerivAt_entropyProfile hs hz.1 (by linarith [hz.2])).differentiableAt
  have hbound : ∀ z ∈ Icc (0 : ℝ) (1 - η),
      ‖deriv (entropyProfile s) z‖ ≤
        regularizedEntropyLipschitzConstant s η := by
    intro z hz
    have hz1 : z < 1 := by linarith [hz.2]
    have hbase := abs_deriv_entropyProfile_le_log_exp_div hs hz.1 hz1
    have htail : 0 < 1 - z := by linarith
    have hηtail : η ≤ 1 - z := by linarith [hz.2]
    have hquot : Real.exp 1 / (1 - z) ≤ Real.exp 1 / η := by
      apply (div_le_div_iff₀ htail hη0).2
      nlinarith [Real.exp_pos 1]
    have hlog : Real.log (Real.exp 1 / (1 - z)) ≤
        Real.log (Real.exp 1 / η) := by
      exact (Real.log_le_log_iff
        (div_pos (Real.exp_pos 1) htail)
        (div_pos (Real.exp_pos 1) hη0)).2 hquot
    rw [Real.norm_eq_abs]
    exact hbase.trans (mul_le_mul_of_nonneg_left hlog
      (endpointDerivativeConstant_nonneg s))
  have hmv := (convex_Icc (0 : ℝ) (1 - η)).norm_image_sub_le_of_norm_deriv_le
    hdiff hbound hy hx
  simpa [Real.norm_eq_abs, abs_sub_comm] using hmv

/-- The clipped entropy profile is Lipschitz on the full singular-value
interval `[0,1]`.  This is the scalar content of the regularization step. -/
theorem abs_regularizedEntropyProfile_sub_le {s η x y : ℝ}
    (hs : s ≠ 0) (hη0 : 0 < η) (hη1 : η ≤ 1)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1)
    (hy0 : 0 ≤ y) (hy1 : y ≤ 1) :
    |regularizedEntropyProfile s η x -
        regularizedEntropyProfile s η y| ≤
      regularizedEntropyLipschitzConstant s η * |x - y| := by
  let cx := clipAtEndpoint η x
  let cy := clipAtEndpoint η y
  have hcx : cx ∈ Icc (0 : ℝ) (1 - η) := by
    constructor
    · exact le_min hx0 (by linarith)
    · exact min_le_right _ _
  have hcy : cy ∈ Icc (0 : ℝ) (1 - η) := by
    constructor
    · exact le_min hy0 (by linarith)
    · exact min_le_right _ _
  have hprofile := abs_entropyProfile_sub_le_cutoff hs hη0 hη1 hcx hcy
  have hclip : |cx - cy| ≤ |x - y| := by
    have h := abs_min_sub_min_le_max x (1 - η) y (1 - η)
    change |min x (1 - η) - min y (1 - η)| ≤ |x - y|
    simpa using h
  change |entropyProfile s cx - entropyProfile s cy| ≤ _
  exact hprofile.trans (mul_le_mul_of_nonneg_left hclip
    (regularizedEntropyLipschitzConstant_nonneg hη0 hη1))

end

end LogdetLean.VonNeumannTypicality
