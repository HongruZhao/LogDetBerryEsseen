import LogdetLean.VonNeumannTypicality.Entropy.FiniteStatistic
import Mathlib.MeasureTheory.Integral.Bochner.Basic

/-!
# Expectation-level entropy lower bounds

This module integrates the deterministic spectral-energy inequality and
packages the elementary divergence transfer used for the entropy mean.
-/

open Filter MeasureTheory
open scoped BigOperators

namespace LogdetLean.VonNeumannTypicality

noncomputable section

/-- The coefficient in the finite spectral-energy lower bound is strictly
positive for nonzero squeezing. -/
theorem entropyEnergyPrefactor_pos {s : ℝ} (hs : s ≠ 0) :
    0 < (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 := by
  have hsinh : Real.sinh (2 * s) ≠ 0 := by
    rw [Real.sinh_ne_zero]
    exact mul_ne_zero (by norm_num) hs
  have htanh : Real.tanh (2 * s) ≠ 0 := by
    rw [Real.tanh_eq_sinh_div_cosh]
    exact div_ne_zero hsinh (Real.cosh_pos _).ne'
  positivity

/-- Expectation-level form of the entropy-energy bound for an arbitrary
probability model (indeed, for any measure for which both sides integrate). -/
theorem integral_entropySpectralStatistic_energy_lower_bound
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} {k : ℕ}
    {s : ℝ} {tau : Ω → Fin k → ℝ}
    (htau0 : ∀ ω i, 0 ≤ tau ω i) (htau1 : ∀ ω i, tau ω i ≤ 1)
    (hEnergy : Integrable (fun ω ↦ ∑ i, (1 - tau ω i ^ 2)) μ)
    (hEntropy : Integrable (fun ω ↦ entropySpectralStatistic s (tau ω)) μ) :
    (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 *
        ∫ ω, (∑ i, (1 - tau ω i ^ 2)) ∂μ ≤
      ∫ ω, entropySpectralStatistic s (tau ω) ∂μ := by
  let c : ℝ := (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2
  have hmono :
      ∫ ω, c * (∑ i, (1 - tau ω i ^ 2)) ∂μ ≤
        ∫ ω, entropySpectralStatistic s (tau ω) ∂μ := by
    apply integral_mono (hEnergy.const_mul c) hEntropy
    intro ω
    exact entropySpectralStatistic_energy_lower_bound (htau0 ω) (htau1 ω)
  rw [integral_const_mul] at hmono
  exact hmono

/-- Abstract final step: if the expected spectral energy diverges, then so
does any entropy mean above it with the positive squeezing prefactor. -/
theorem entropyMean_tendsto_atTop_of_energyMean {s : ℝ} (hs : s ≠ 0)
    {energyMean entropyMean : ℕ → ℝ}
    (hlower : ∀ N,
      (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 * energyMean N ≤ entropyMean N)
    (henergy : Tendsto energyMean atTop atTop) :
    Tendsto entropyMean atTop atTop := by
  have hprefactor : Tendsto
      (fun N ↦ (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 * energyMean N)
      atTop atTop :=
    henergy.const_mul_atTop (entropyEnergyPrefactor_pos hs)
  exact tendsto_atTop_mono hlower hprefactor

end

end LogdetLean.VonNeumannTypicality
