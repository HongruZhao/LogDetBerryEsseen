import LogdetLean.VonNeumannTypicality.Entropy.FiniteStatistic
import LogdetLean.VonNeumannTypicality.Entropy.Monotonicity

/-!
# Deterministic cutoff approximation

Monotonicity gives an exact approximation bound without probability or
matrix theory: clipping any singular value at `1-η` changes its entropy by at
most the endpoint value `φ_s(1-η)`.
-/

open scoped BigOperators

namespace LogdetLean.VonNeumannTypicality

noncomputable section

theorem abs_entropyProfile_sub_regularized_le_endpoint {s η t : ℝ}
    (hη0 : 0 < η) (hη1 : η ≤ 1) (ht0 : 0 ≤ t) (ht1 : t ≤ 1) :
    |entropyProfile s t - regularizedEntropyProfile s η t| ≤
      entropyProfile s (1 - η) := by
  by_cases ht : t ≤ 1 - η
  · rw [regularizedEntropyProfile_eq_self ht, sub_self, abs_zero]
    exact entropyProfile_nonneg (by linarith) (by linarith)
  have het : 1 - η ≤ t := le_of_not_ge ht
  rw [regularizedEntropyProfile_eq_endpoint het]
  have hend : 1 - η ∈ Set.Icc (0 : ℝ) 1 := ⟨by linarith, by linarith⟩
  have htt : t ∈ Set.Icc (0 : ℝ) 1 := ⟨ht0, ht1⟩
  have hanti := entropyProfile_antitoneOn s hend htt het
  have hnonneg := entropyProfile_nonneg (s := s) ht0 ht1
  rw [abs_of_nonpos (sub_nonpos.mpr hanti)]
  linarith

/-- Uniform deterministic approximation for a finite spectral statistic. -/
theorem abs_entropySpectralStatistic_sub_regularized_le {k : ℕ}
    {s η : ℝ} {τ : Fin k → ℝ}
    (hη0 : 0 < η) (hη1 : η ≤ 1)
    (hτ0 : ∀ i, 0 ≤ τ i) (hτ1 : ∀ i, τ i ≤ 1) :
    |entropySpectralStatistic s τ -
        regularizedEntropySpectralStatistic s η τ| ≤
      k * entropyProfile s (1 - η) := by
  unfold entropySpectralStatistic regularizedEntropySpectralStatistic
  rw [← Finset.sum_sub_distrib]
  calc
    |∑ i, (entropyProfile s (τ i) -
        regularizedEntropyProfile s η (τ i))|
        ≤ ∑ i, |entropyProfile s (τ i) -
            regularizedEntropyProfile s η (τ i)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _i : Fin k, entropyProfile s (1 - η) :=
      Finset.sum_le_sum fun i _ ↦
        abs_entropyProfile_sub_regularized_le_endpoint
          hη0 hη1 (hτ0 i) (hτ1 i)
    _ = k * entropyProfile s (1 - η) := by simp

end

end LogdetLean.VonNeumannTypicality
