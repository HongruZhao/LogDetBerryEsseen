import LogdetLean.VonNeumannTypicality.Entropy.Regularization
import LogdetLean.VonNeumannTypicality.Entropy.MeanLowerAlgebra
import LogdetLean.VonNeumannTypicality.Entropy.RenyiComparison

/-!
# Finite spectral entropy statistics

This module lifts the scalar regularization and Rényi-2 lower bounds to a
finite list of singular values.  It is independent of any matrix theorem:
later files may instantiate the list with the singular values of a truncated
COE block.
-/

open scoped BigOperators

namespace LogdetLean.VonNeumannTypicality

noncomputable section

/-- Von Neumann entropy as a finite singular-value statistic. -/
def entropySpectralStatistic {k : ℕ} (s : ℝ) (τ : Fin k → ℝ) : ℝ :=
  ∑ i, entropyProfile s (τ i)

/-- Regularized finite entropy statistic. -/
def regularizedEntropySpectralStatistic {k : ℕ}
    (s η : ℝ) (τ : Fin k → ℝ) : ℝ :=
  ∑ i, regularizedEntropyProfile s η (τ i)

/-- Finite Rényi-2 profile sum. -/
def renyiTwoSpectralStatistic {k : ℕ} (s : ℝ) (τ : Fin k → ℝ) : ℝ :=
  ∑ i, renyiTwoProfile s (τ i)

/-- Finite-dimensional version of `S₁ ≥ S₂`. -/
theorem renyiTwoSpectralStatistic_le_entropySpectralStatistic {k : ℕ}
    {s : ℝ} {τ : Fin k → ℝ}
    (hτ0 : ∀ i, 0 ≤ τ i) (hτ1 : ∀ i, τ i ≤ 1) :
    renyiTwoSpectralStatistic s τ ≤ entropySpectralStatistic s τ := by
  unfold renyiTwoSpectralStatistic entropySpectralStatistic
  exact Finset.sum_le_sum fun i _ ↦
    renyiTwoProfile_le_entropyProfile (hτ0 i) (hτ1 i)

theorem renyiTwoSpectralStatistic_lower_bound {k : ℕ}
    {s : ℝ} {τ : Fin k → ℝ}
    (hτ0 : ∀ i, 0 ≤ τ i) (hτ1 : ∀ i, τ i ≤ 1) :
    (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 *
        (∑ i, (1 - τ i ^ 2)) ≤
      renyiTwoSpectralStatistic s τ := by
  unfold renyiTwoSpectralStatistic
  calc
    (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 *
          (∑ i, (1 - τ i ^ 2))
        = ∑ i, (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 *
            (1 - τ i ^ 2) := by rw [Finset.mul_sum]
    _ ≤ ∑ i, renyiTwoProfile s (τ i) :=
      Finset.sum_le_sum fun i _ ↦ renyiTwoProfile_lower_bound (hτ0 i) (hτ1 i)

/-- Complete deterministic energy lower bound for the finite von Neumann
entropy statistic. -/
theorem entropySpectralStatistic_energy_lower_bound {k : ℕ}
    {s : ℝ} {τ : Fin k → ℝ}
    (hτ0 : ∀ i, 0 ≤ τ i) (hτ1 : ∀ i, τ i ≤ 1) :
    (1 / 2 : ℝ) * Real.tanh (2 * s) ^ 2 *
        (∑ i, (1 - τ i ^ 2)) ≤
      entropySpectralStatistic s τ :=
  (renyiTwoSpectralStatistic_lower_bound hτ0 hτ1).trans
    (renyiTwoSpectralStatistic_le_entropySpectralStatistic hτ0 hτ1)

/-- The scalar Lipschitz estimate summed over finitely many singular values. -/
theorem abs_regularizedEntropySpectralStatistic_sub_le_lone {k : ℕ}
    {s η : ℝ} {τ υ : Fin k → ℝ}
    (hs : s ≠ 0) (hη0 : 0 < η) (hη1 : η ≤ 1)
    (hτ0 : ∀ i, 0 ≤ τ i) (hτ1 : ∀ i, τ i ≤ 1)
    (hυ0 : ∀ i, 0 ≤ υ i) (hυ1 : ∀ i, υ i ≤ 1) :
    |regularizedEntropySpectralStatistic s η τ -
        regularizedEntropySpectralStatistic s η υ| ≤
      regularizedEntropyLipschitzConstant s η *
        ∑ i, |τ i - υ i| := by
  unfold regularizedEntropySpectralStatistic
  rw [← Finset.sum_sub_distrib]
  calc
    |∑ i, (regularizedEntropyProfile s η (τ i) -
        regularizedEntropyProfile s η (υ i))|
        ≤ ∑ i, |regularizedEntropyProfile s η (τ i) -
            regularizedEntropyProfile s η (υ i)| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ i, regularizedEntropyLipschitzConstant s η * |τ i - υ i| :=
      Finset.sum_le_sum fun i _ ↦
        abs_regularizedEntropyProfile_sub_le hs hη0 hη1
          (hτ0 i) (hτ1 i) (hυ0 i) (hυ1 i)
    _ = regularizedEntropyLipschitzConstant s η * ∑ i, |τ i - υ i| := by
      rw [Finset.mul_sum]

/-- Paper-facing Euclidean version, obtained by finite Cauchy--Schwarz. -/
theorem abs_regularizedEntropySpectralStatistic_sub_le_ltwo {k : ℕ}
    {s η : ℝ} {τ υ : Fin k → ℝ}
    (hs : s ≠ 0) (hη0 : 0 < η) (hη1 : η ≤ 1)
    (hτ0 : ∀ i, 0 ≤ τ i) (hτ1 : ∀ i, τ i ≤ 1)
    (hυ0 : ∀ i, 0 ≤ υ i) (hυ1 : ∀ i, υ i ≤ 1) :
    |regularizedEntropySpectralStatistic s η τ -
        regularizedEntropySpectralStatistic s η υ| ≤
      regularizedEntropyLipschitzConstant s η *
        Real.sqrt k * Real.sqrt (∑ i, (τ i - υ i) ^ 2) := by
  have hlone := abs_regularizedEntropySpectralStatistic_sub_le_lone
    hs hη0 hη1 hτ0 hτ1 hυ0 hυ1
  have hcs := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ
    (fun _ : Fin k ↦ (1 : ℝ)) (fun i ↦ |τ i - υ i|)
  have hsum : (∑ i, |τ i - υ i|) ≤
      Real.sqrt k * Real.sqrt (∑ i, (τ i - υ i) ^ 2) := by
    simpa [sq_abs] using hcs
  have hmul := mul_le_mul_of_nonneg_left hsum
    (regularizedEntropyLipschitzConstant_nonneg (s := s) hη0 hη1)
  simpa [mul_assoc] using hlone.trans hmul

end

end LogdetLean.VonNeumannTypicality
