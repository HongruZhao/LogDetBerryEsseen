import LogdetLean.VonNeumannTypicality.WeakTypicality.Probability
import LogdetLean.VonNeumannTypicality.Entropy.CutoffRate

/-!
# Probabilistic removal of the entropy cutoff

The inverse-square clipping error is uniformly `o(1)`.  This module combines
that deterministic estimate with the abstract weak-typicality transfer, so
no random-matrix input is needed at this stage.
-/

open Filter MeasureTheory

namespace LogdetLean.VonNeumannTypicality

noncomputable section

/-- The deterministic total error used to remove the inverse-square cutoff. -/
def inverseSquareCutoffTotalError (s : ℝ) (N : ℕ) : ℝ :=
  (N : ℝ) * entropyProfile s (1 - inverseSquareCutoff N)

theorem tendsto_inverseSquareCutoffTotalError (s : ℝ) :
    Tendsto (inverseSquareCutoffTotalError s) atTop (nhds 0) :=
  tendsto_nat_mul_entropyProfile_inverseSquareCutoff s

/-- Weak typicality of the inverse-square regularized entropy implies weak
typicality of the original von Neumann entropy, for any positive diverging
normalizer and any triangular family of spectra in `[0,1]`. -/
theorem weaklyTypical_entropySpectralStatistic_of_regularized
    {Ω : ℕ → Type*} [∀ N, MeasurableSpace (Ω N)]
    (μ : (N : ℕ) → Measure (Ω N))
    [∀ N, IsProbabilityMeasure (μ N)]
    (s : ℝ) (tau : (N : ℕ) → Ω N → Fin N → ℝ) (m : ℕ → ℝ)
    (htau0 : ∀ N ω i, 0 ≤ tau N ω i)
    (htau1 : ∀ N ω i, tau N ω i ≤ 1)
    (hm : Tendsto m atTop atTop)
    (hregularized : WeaklyTypical μ
      (fun N ω ↦ regularizedEntropySpectralStatistic s
        (inverseSquareCutoff N) (tau N ω)) m) :
    WeaklyTypical μ
      (fun N ω ↦ entropySpectralStatistic s (tau N ω)) m := by
  let δ : ℕ → ℝ := fun N ↦ inverseSquareCutoffTotalError s N / m N
  have hmpos : ∀ᶠ N in atTop, 0 < m N :=
    hm.eventually (eventually_gt_atTop (0 : ℝ))
  have hδ : Tendsto δ atTop (nhds 0) :=
    (tendsto_inverseSquareCutoffTotalError s).div_atTop hm
  have happrox : ∀ᶠ N in atTop, ∀ ω,
      |entropySpectralStatistic s (tau N ω) -
          regularizedEntropySpectralStatistic s (inverseSquareCutoff N)
            (tau N ω)| ≤ δ N * m N := by
    filter_upwards [eventually_ge_atTop 1, hmpos] with N hN hmN
    intro ω
    have hbound := abs_entropySpectralStatistic_sub_regularized_le
      (s := s) (η := inverseSquareCutoff N) (τ := tau N ω)
      (by
        unfold inverseSquareCutoff
        exact inv_pos.mpr (sq_pos_of_pos (by exact_mod_cast hN)))
      (inverseSquareCutoff_le_one hN)
      (htau0 N ω) (htau1 N ω)
    calc
      |entropySpectralStatistic s (tau N ω) -
          regularizedEntropySpectralStatistic s (inverseSquareCutoff N)
            (tau N ω)| ≤ inverseSquareCutoffTotalError s N := hbound
      _ = δ N * m N := by
        dsimp [δ]
        field_simp
  exact weaklyTypical_of_uniform_approximation μ _ _ m δ
    hmpos hδ happrox hregularized

end

end LogdetLean.VonNeumannTypicality
