import LogdetLean.VonNeumannTypicality.WeakTypicality.TransferAlgebra
import Mathlib.MeasureTheory.Measure.Typeclasses.Probability

/-!
# Weak typicality on a triangular family of probability spaces

This file packages the paper's probabilistic definition and proves the
generic uniform-approximation transfer.  It is independent of Haar measure,
matrices, and entropy.
-/

open Filter MeasureTheory Set

namespace LogdetLean.VonNeumannTypicality

noncomputable section

/-- The event that a statistic differs from its normalizer by at least a
relative amount `epsilon`. -/
def relativeBadEvent {Ω : Type*} (X : Ω → ℝ) (m ε : ℝ) : Set Ω :=
  {ω | ε ≤ |X ω / m - 1|}

/-- Weak typicality for a triangular family: every fixed relative-error bad
event has probability tending to zero. -/
def WeaklyTypical
    {Ω : ℕ → Type*} [∀ N, MeasurableSpace (Ω N)]
    (μ : (N : ℕ) → Measure (Ω N))
    (X : (N : ℕ) → Ω N → ℝ) (m : ℕ → ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε →
    Tendsto
      (fun N ↦ (μ N (relativeBadEvent (X N) (m N) ε)).toReal)
      atTop (nhds 0)

/-- A deterministic relative approximation turns a bad event for `X` into a
bad event for `Y` at half the tolerance. -/
theorem relativeBadEvent_subset_of_approximation
    {Ω : Type*} {X Y : Ω → ℝ} {m δ ε : ℝ}
    (hm : 0 < m) (hδ : δ < ε / 2)
    (happrox : ∀ ω, |X ω - Y ω| ≤ δ * m) :
    relativeBadEvent X m ε ⊆ relativeBadEvent Y m (ε / 2) := by
  intro ω hbad
  change ε ≤ |X ω / m - 1| at hbad
  change ε / 2 ≤ |Y ω / m - 1|
  have hbound := abs_div_sub_one_le_of_approximation hm (happrox ω)
  linarith

/-- Weak typicality is stable under a uniform `o(m_N)` perturbation. -/
theorem weaklyTypical_of_uniform_approximation
    {Ω : ℕ → Type*} [∀ N, MeasurableSpace (Ω N)]
    (μ : (N : ℕ) → Measure (Ω N))
    [∀ N, IsProbabilityMeasure (μ N)]
    (X Y : (N : ℕ) → Ω N → ℝ) (m δ : ℕ → ℝ)
    (hm : ∀ᶠ N in atTop, 0 < m N)
    (hδ : Tendsto δ atTop (nhds 0))
    (happrox : ∀ᶠ N in atTop, ∀ ω, |X N ω - Y N ω| ≤ δ N * m N)
    (hY : WeaklyTypical μ Y m) :
    WeaklyTypical μ X m := by
  intro ε hε
  have hYε := hY (ε / 2) (half_pos hε)
  refine squeeze_zero' (Eventually.of_forall fun N ↦ ENNReal.toReal_nonneg) ?_ hYε
  have hδsmall : ∀ᶠ N in atTop, δ N < ε / 2 :=
    hδ.eventually (Iio_mem_nhds (half_pos hε))
  filter_upwards [hm, hδsmall, happrox] with N hmN hδN happN
  apply ENNReal.toReal_mono (measure_ne_top (μ N) _)
  apply measure_mono
  exact relativeBadEvent_subset_of_approximation hmN hδN happN

end

end LogdetLean.VonNeumannTypicality
