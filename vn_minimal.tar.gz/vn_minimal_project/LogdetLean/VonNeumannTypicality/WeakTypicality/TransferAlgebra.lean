import LogdetLean.VonNeumannTypicality.Entropy.CutoffTransfer

/-!
# Transfer algebra for weak typicality

These deterministic inequalities and filter limits are the final algebraic
step in passing from a regularized statistic to the original statistic.
They deliberately do not assume a particular probability model.
-/

open Filter

namespace LogdetLean.VonNeumannTypicality

noncomputable section

/-- Relative deviation of `x` is bounded by the approximation error `x-y`
plus the relative deviation of `y`. -/
theorem abs_div_sub_one_le_approximation {x y m : ℝ} (hm : m ≠ 0) :
    |x / m - 1| ≤ |x - y| / |m| + |y / m - 1| := by
  have hdecomp : x / m - 1 = (x - y) / m + (y / m - 1) := by
    field_simp
    ring
  rw [hdecomp]
  calc
    |(x - y) / m + (y / m - 1)| ≤
        |(x - y) / m| + |y / m - 1| := abs_add_le _ _
    _ = |x - y| / |m| + |y / m - 1| := by rw [abs_div]

/-- Positive-normalizer form useful in event inclusions. -/
theorem abs_div_sub_one_le_of_approximation {x y m delta : ℝ}
    (hm : 0 < m) (hxy : |x - y| ≤ delta * m) :
    |x / m - 1| ≤ delta + |y / m - 1| := by
  calc
    |x / m - 1| ≤ |x - y| / |m| + |y / m - 1| :=
      abs_div_sub_one_le_approximation hm.ne'
    _ ≤ (delta * m) / |m| + |y / m - 1| := by
      gcongr
    _ = delta + |y / m - 1| := by rw [abs_of_pos hm]; field_simp

/-- If the approximation error is smaller than `delta` and the approximate
relative deviation is smaller than `epsilon-delta`, then the original
relative deviation is smaller than `epsilon`. -/
theorem relative_deviation_lt_of_approximation {x y m delta epsilon : ℝ}
    (hm : 0 < m) (hxy : |x - y| ≤ delta * m)
    (hy : |y / m - 1| < epsilon - delta) :
    |x / m - 1| < epsilon := by
  have h := abs_div_sub_one_le_of_approximation hm hxy
  linarith

/-- Abstract limit version: an additive `o(1)` perturbation of a statistic
with diverging normalizer preserves convergence of the normalized ratio to
one. -/
theorem tendsto_ratio_one_of_tendsto_sub_zero
    {α : Type*} {l : Filter α} {x y m : α → ℝ}
    (hxy : Tendsto (fun a ↦ x a - y a) l (nhds 0))
    (hm : Tendsto m l atTop)
    (hy : Tendsto (fun a ↦ y a / m a) l (nhds 1)) :
    Tendsto (fun a ↦ x a / m a) l (nhds 1) := by
  have herr : Tendsto (fun a ↦ (x a - y a) / m a) l (nhds 0) :=
    hxy.div_atTop hm
  have hsum := herr.add hy
  have hsum1 : Tendsto
      (fun a ↦ (x a - y a) / m a + y a / m a) l (nhds 1) := by
    simpa using hsum
  apply hsum1.congr'
  filter_upwards [hm.eventually (eventually_gt_atTop (0 : ℝ))] with a hma
  field_simp
  ring

end

end LogdetLean.VonNeumannTypicality
