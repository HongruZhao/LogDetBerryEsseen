# Copyright and permitted verification use

Copyright (c) 2026 Hongru Zhao. All rights reserved.

Permission is granted to download, extract, inspect, and run this capsule for
proof verification, peer review, and noncommercial scholarly research. This
permission does not grant a general right to modify, redistribute,
sublicense, or commercially exploit the source. Contact the copyright holder
before any broader reuse.

This notice applies to the project-authored material in this capsule. It does
not replace the licenses of Lean, mathlib, or any transitive external
dependency downloaded by Lake. Those projects remain governed by their own
copyright and license terms.

Mathematical facts and citations to prior literature are included for
scholarly attribution. This notice does not claim ownership of prior
mathematical results.

The author may replace this verification-only permission with an explicit
open-source license in a later release. Until then, no broader license should
be inferred.
