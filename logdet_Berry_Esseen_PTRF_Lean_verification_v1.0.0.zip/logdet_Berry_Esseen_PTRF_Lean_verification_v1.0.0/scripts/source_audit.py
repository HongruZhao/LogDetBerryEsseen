#!/usr/bin/env python3
"""Fail-closed audit of the public capsule's local files."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "LogdetLean"
EXPECTED_LEAN_FILES = 137
ALLOWED_EXTERNAL_IMPORT_PREFIX = "Mathlib"
EXPECTED_TOOLCHAIN = "leanprover/lean4:v4.33.0-rc2"
EXPECTED_MATHLIB_REV = "641fbd329d4ffb62bef83c51f54088469056bd36"


def mask_lean_comments_and_strings(text: str) -> str:
    """Preserve newlines while masking nested comments and string contents."""
    out: list[str] = []
    i = 0
    block_depth = 0
    in_line = False
    in_string = False
    escaped = False
    while i < len(text):
        pair = text[i : i + 2]
        ch = text[i]
        if in_line:
            if ch == "\n":
                in_line = False
                out.append("\n")
            else:
                out.append(" ")
            i += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                out.extend((" ", " "))
                i += 2
            elif pair == "-/":
                block_depth -= 1
                out.extend((" ", " "))
                i += 2
            else:
                out.append("\n" if ch == "\n" else " ")
                i += 1
            continue
        if in_string:
            out.append("\n" if ch == "\n" else " ")
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            i += 1
            continue
        if pair == "--":
            in_line = True
            out.extend((" ", " "))
            i += 2
        elif pair == "/-":
            block_depth = 1
            out.extend((" ", " "))
            i += 2
        elif ch == '"':
            in_string = True
            out.append(" ")
            i += 1
        else:
            out.append(ch)
            i += 1
    if block_depth or in_string:
        raise ValueError("unterminated Lean comment or string")
    return "".join(out)


def main() -> int:
    failures: list[str] = []
    lean_files = sorted([ROOT / "LogdetLean.lean", *SOURCE.rglob("*.lean")])
    if not lean_files:
        failures.append("no Lean source files found")
    if len(lean_files) != EXPECTED_LEAN_FILES:
        failures.append(
            f"unexpected Lean source count: {len(lean_files)} "
            f"(expected {EXPECTED_LEAN_FILES})"
        )

    forbidden_tree_names = {".git", ".lake", "__pycache__"}
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if any(part in forbidden_tree_names for part in rel.parts):
            failures.append(f"forbidden generated/private path: {rel}")
        if path.is_symlink():
            failures.append(f"symbolic link is not allowed: {rel}")
        if path.is_file() and path.suffix in {
            ".olean", ".ilean", ".trace", ".c", ".o", ".a", ".so",
            ".dylib", ".dll", ".pyc",
        }:
            failures.append(f"compiled artifact is not allowed: {rel}")
        if path.name == ".DS_Store":
            failures.append(f"macOS metadata is not allowed: {rel}")
        if path.is_file() and b"\x00" in path.read_bytes():
            failures.append(f"binary/NUL-containing file is not allowed: {rel}")

    trust_keyword_pattern = re.compile(
        r"\b(?:sorry|admit|sorryAx|axiom|postulate|constant|constants|unsafe)\b"
    )
    forbidden_code_patterns = {
        "proof placeholder": re.compile(r"\b(?:sorry|admit|sorryAx)\b"),
        "environment declaration escape": re.compile(
            r"(?:\.axiomDecl\b|\b(?:Lean\.)?addDecl\b|^\s*run_cmd\b)",
            re.MULTILINE,
        ),
        "unsafe local declaration": re.compile(
            r"(?m)^\s*(?:private\s+|protected\s+)?unsafe\s+"
            r"(?:def|theorem|opaque|instance)\b"
        ),
        "external/native implementation escape": re.compile(
            r"\b(?:extern|implemented_by|native_decide|by_native_decide|"
            r"run_tac|ofReduceBool)\b"
        ),
        "custom elaboration or initialization": re.compile(
            r"(?m)^\s*(?:elab|elab_rules|command_elab|macro|macro_rules|syntax|"
            r"declare_syntax_cat|initialize)\b"
        ),
    }
    secret_patterns = {
        "GitHub token": re.compile(
            "(?:" + "ghp" + r"_|github" + r"_pat_)[A-Za-z0-9_]+"
        ),
        "OpenAI-like secret": re.compile(
            r"\b" + "sk" + r"-[A-Za-z0-9_-]{16,}"
        ),
        "AWS access key": re.compile(
            r"\b" + "AK" + r"IA[0-9A-Z]{16}\b"
        ),
        "private key": re.compile(
            "BEGIN (?:RSA |EC |OPENSSH )?PRIVATE " + "KEY"
        ),
    }
    # Construct these markers without embedding a forbidden example literally
    # in this audit script (which audits itself).
    machine_paths = re.compile(
        "(?:/" + "Users/|/" + "home/|/private/" +
        r"var/|[A-Za-z]:\\" + "Users" + r"\\)"
    )

    for path in lean_files:
        rel = path.relative_to(ROOT)
        raw = path.read_text(encoding="utf-8")
        try:
            code = mask_lean_comments_and_strings(raw)
        except ValueError as exc:
            failures.append(f"{rel}: {exc}")
            continue
        if trust_keyword_pattern.search(code):
            failures.append(f"{rel}: forbidden trust keyword in executable Lean code")
        for label, pattern in forbidden_code_patterns.items():
            if pattern.search(code):
                failures.append(f"{rel}: {label}")
        if machine_paths.search(raw):
            failures.append(f"{rel}: machine-specific absolute path")
        for match in re.finditer(r"(?m)^\s*import\s+([^\s]+)\s*$", code):
            module = match.group(1)
            if module.startswith("LogdetLean."):
                if "Paper2608" in module or module.startswith("LogdetLean.Coherence"):
                    failures.append(
                        f"{rel}: import from excluded project package {module}"
                    )
                target = ROOT / (module.replace(".", "/") + ".lean")
                if not target.is_file():
                    failures.append(
                        f"{rel}: local import resolves outside capsule or is missing: {module}"
                    )
            elif not (module == ALLOWED_EXTERNAL_IMPORT_PREFIX or
                      module.startswith(ALLOWED_EXTERNAL_IMPORT_PREFIX + ".")):
                failures.append(f"{rel}: unapproved external import: {module}")

    config = (ROOT / "lakefile.toml").read_text(encoding="utf-8")
    if re.search(r"(?m)^\s*path\s*=", config):
        failures.append("lakefile.toml contains a local path dependency")
    if 'name = "logdet_berry_esseen_lean"' not in config:
        failures.append("lakefile.toml does not preserve the release package name")
    if f'rev = "{EXPECTED_MATHLIB_REV}"' not in config:
        failures.append("lakefile.toml does not pin the audited mathlib revision")
    toolchain = (ROOT / "lean-toolchain").read_text(encoding="utf-8").strip()
    if toolchain != EXPECTED_TOOLCHAIN:
        failures.append(
            f"unexpected lean-toolchain: {toolchain!r} (expected {EXPECTED_TOOLCHAIN!r})"
        )

    manifest_path = ROOT / "lake-manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        failures.append(f"invalid lake-manifest.json: {exc}")
        manifest = {}
    if manifest.get("name") != "logdet_berry_esseen_lean":
        failures.append("lake-manifest.json has the wrong package name")
    mathlib_packages = [
        p for p in manifest.get("packages", []) if p.get("name") == "mathlib"
    ]
    if len(mathlib_packages) != 1 or mathlib_packages[0].get("rev") != EXPECTED_MATHLIB_REV:
        failures.append("lake-manifest.json does not contain the exact audited mathlib revision")
    for package in manifest.get("packages", []):
        if package.get("type") != "git":
            failures.append(
                f"manifest dependency {package.get('name', '<unknown>')} is not a pinned git dependency"
            )
        url = str(package.get("url", ""))
        if not url.startswith("https://github.com/") or "@" in url.removeprefix("https://"):
            failures.append(
                f"manifest dependency {package.get('name', '<unknown>')} has a non-public or credentialed URL"
            )
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and machine_paths.search(
            path.read_text(encoding="utf-8", errors="ignore")
        ):
            failures.append(
                f"{path.relative_to(ROOT)}: machine-specific absolute path"
            )
        if path.is_file():
            raw = path.read_text(encoding="utf-8", errors="ignore")
            for label, pattern in secret_patterns.items():
                if pattern.search(raw):
                    failures.append(f"{path.relative_to(ROOT)}: possible {label}")

    # Prove infrastructure minimality: every shipped Lean file must be reachable
    # from either the public root or the narrow endpoint audit, and every local
    # import encountered above must be shipped.
    def local_imports(path: Path) -> list[Path]:
        code = mask_lean_comments_and_strings(path.read_text(encoding="utf-8"))
        result: list[Path] = []
        for match in re.finditer(r"(?m)^\s*import\s+(LogdetLean(?:\.[^\s]+)?)\s*$", code):
            module = match.group(1)
            target = ROOT / "LogdetLean.lean" if module == "LogdetLean" else \
                ROOT / (module.replace(".", "/") + ".lean")
            result.append(target)
        return result

    reachable: set[Path] = set()
    pending = [ROOT / "LogdetLean.lean", SOURCE / "PaperAxiomAudit.lean"]
    while pending:
        path = pending.pop()
        if path in reachable:
            continue
        if not path.is_file():
            failures.append(f"closure root/import is missing: {path.relative_to(ROOT)}")
            continue
        reachable.add(path)
        pending.extend(local_imports(path))
    shipped = set(lean_files)
    if reachable != shipped:
        for path in sorted(shipped - reachable):
            failures.append(f"unreachable extra Lean source: {path.relative_to(ROOT)}")
        for path in sorted(reachable - shipped):
            failures.append(f"reachable Lean source omitted from inventory: {path.relative_to(ROOT)}")

    if not (ROOT / "PROVENANCE.md").is_file():
        failures.append("paper-specific PROVENANCE.md is missing")

    if failures:
        print("SOURCE AUDIT FAILED", file=sys.stderr)
        for item in failures:
            print(f"- {item}", file=sys.stderr)
        return 1
    print(f"Source audit passed for {len(lean_files)} Lean source files.")
    print("All local imports resolve inside the capsule; all external imports are Mathlib.")
    print("No sorry, admit, sorryAx, project axiom, postulate, constant declaration,")
    print("unsafe/native/environment escape, custom elaborator, symbolic link, compiled")
    print("proof artifact, machine-specific path, or recognized credential was found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
