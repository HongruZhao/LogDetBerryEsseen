import LogdetLean.NullUniformEdgeworthTarget
import LogdetLean.GeneralRPaperExactTranslation
import LogdetLean.NullVUniformAsymptotics
import LogdetLean.NullSharpSupremumDecimal

/-!
# Table 2 public endpoints

This narrow module is the public interface advertised in the paper's Table 2.
It does not broaden the paper-facing verification claim to other declarations
that happen to lie in the transitive source dependency cone.
-/

#check LogdetLean.map_centeredSampleCorrelationDet_succ_eq_map_product_betaFactors
#check LogdetLean.uniformNullEdgeworthTarget_proved
#check LogdetLean.tendsto_uniformActualNullSharpKolmogorov_relative_error_zero
#check LogdetLean.paperTheoremFiveOne_exact
#check LogdetLean.paperTheoremFiveTwo_exact
#check LogdetLean.paperTheoremFiveTwo_arbitraryCovariance_exact
#check LogdetLean.tendsto_nullASeries_div_uniformScale
#check LogdetLean.tendsto_nullVSeries_div_uniformScale
#check LogdetLean.tendsto_scaledNullKolmogorovSup_closed
#check LogdetLean.nullSharpSupremumConstant_decimal8
